# i3wm-config — monochrome i3 edition

An **i3wm (X11)** port of [LinuxBeginnings/Hyprland-Dots](https://github.com/LinuxBeginnings/Hyprland-Dots).
Hyprland is a Wayland compositor, so every Wayland-only piece was swapped for an X11 equivalent while keeping
the keybinds, and restyled as a **simple, sleek black & white** desktop: flat white-on-black polybar with roman-numeral
workspaces, chunky borders and gaps, monochrome rofi / dunst / kitty / ghostty / cava, grayscale wallpapers, and a
**Pokémon fastfetch** greeting in every new kitty window.

**Design & tools** follow [addy-dclxvi/i3-starterpack](https://github.com/addy-dclxvi/i3-starterpack) (gaps, thick borders, roman workspaces),
[TheDistroHopper/i3wm-nord](https://github.com/TheDistroHopper/i3wm-nord) and [traumachan7219-collab/i3-dots](https://github.com/traumachan7219-collab/i3-dots)
(i3 + polybar + picom + rofi + dunst + kitty + feh + i3lock), recolored to pure monochrome. The keybinds are unchanged (`SUPER+H` lists them).

## Quick start

Works from a **KDE or GNOME** desktop (or anything else): the installer adds i3 and Xorg *next to* your current desktop,
so you keep both and pick one at the login screen. Primary target: **Fedora**; also Arch-based and Debian/Ubuntu-based systems.

```bash
git clone https://github.com/OmitGhostly/i3wm-config.git
cd i3wm-config
chmod +x install.sh
./install.sh
```

Or without cloning:

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/OmitGhostly/i3wm-config/main/install.sh)
```

Then log out and choose the **i3** session (GNOME: gear icon on the login screen; KDE: session menu, bottom-left).
Press **`SUPER + H`** for the full keybind list. Do not run it with `sudo` - it asks for your password only when installing packages.

### Installer options

| Option | What it does |
|---|---|
| *(none)* | Install i3 + all dependencies, then the dotfiles |
| `--no-packages` | Only copy the dotfiles (you already have the programs) |
| `--wallpapers` | Also download the full KooL wallpaper bank into `~/Pictures/wallpapers` |
| `--no-backup` | Overwrite existing configs instead of moving them aside |
| `--restore` | Put back the newest `*.bak-*` backups and exit |
| `--dry-run` | Print what would happen without changing anything |

Existing folders in `~/.config` that the installer replaces are moved to `<name>.bak-<timestamp>`.
Every run is logged to `~/.cache/i3wm-dots-install.log` - attach it when reporting a problem.
Each package is checked against your distro's repos before installing, so one missing name never aborts the rest;
anything that could not be installed is listed at the end.

### Fedora notes

- **Xorg is required.** The installer adds `xorg-x11-server-Xorg`. i3 is an X11 window manager; it runs as its own login session even if your GNOME/KDE session is Wayland.
- **Login screen:** if "i3" is missing from the session list, your display manager may not offer X11 sessions (recent Fedora releases moved GNOME to Wayland-only). SDDM and LightDM do:
  `sudo dnf install sddm && sudo systemctl disable gdm && sudo systemctl enable sddm`
- **clipmenu** is not in Fedora's repos, so the installer uses **CopyQ** instead (same keybind, `SUPER+ALT+V`).
- **Pokémon fastfetch:** the installer adds `fastfetch` and [pokemon-colorscripts](https://gitlab.com/phoneybadger/pokemon-colorscripts) and a one-line greeting in `~/.zshrc` / `~/.bashrc` that only runs inside kitty. Skip it with `--no-pokemon`.
- **FantasqueSansM Nerd Font** (bar/terminal icons) is downloaded to `~/.local/share/fonts` if missing.
- Requires **i3 >= 4.22** (`gaps` are built in); current Fedora releases ship newer.

## Compatibility

Checked against the real tools, not only the docs:

| Tool | Check | Result |
|---|---|---|
| i3 4.23 | `i3 -C` config validation (all 151 binds, window rules, autostart) | passes |
| Polybar 3.7 | bar starts with all modules; i3 reserves the bar's space (workspace starts below the bar) | passes |
| picom 10 | starts with the shipped config; Fedora ships picom 13 (same options) | passes |
| dunst 1.9 | config parses without warnings (older-syntax values chosen for compatibility) | passes |
| rofi 1.7.5 | all 41 shipped `.rasi` themes/configs parse | passes |
| Scripts | `bash -n` + `shellcheck` clean; screenshot, wallpaper, reload, compositor toggle ran in a virtual X server | passes |

Fixed along the way: Polybar's `override-redirect` made i3 ignore the bar's reserved space (windows tiled underneath it) - removed.
Polybar, picom and pamixer are in Fedora 43/44 repos (confirmed on packages.fedoraproject.org).
**Not yet tested on real hardware:** dunst running (needs a desktop D-Bus session), lock screen, touchpad / brightness / media keys, multi-monitor, and a real `dnf` run.

## Repository layout

```
├── install.sh          installer (see options above)
├── config/             mirrors ~/.config
│   ├── i3/             i3 config, scripts/, rofi/, icons/, defaults.conf
│   ├── polybar/        bar (replaces Waybar)
│   ├── picom/          compositor: blur, rounded corners, shadows
│   ├── dunst/          notifications (replaces swaync)
│   └── kitty/ ghostty/ wezterm/ starship/ fastfetch/ btop/ yazi/ cava/ Kvantum/ qt5ct/ qt6ct/ swappy/
├── wallpapers/         a few starter wallpapers
└── LICENSE.md          GPL-3.0 (inherited from the original project)
```

## What replaced what

| Hyprland dots | This port |
|---|---|
| Hyprland config (Lua) | `config/i3/config` — 151 keybinds, window rules, autostart |
| Waybar | Polybar (one bar per monitor, tray on primary) |
| swaync | dunst — `SUPER+SHIFT+N` shows history |
| Hyprland blur / rounding / shadow / dim | picom |
| swww / awww | feh (`Wallpaper.sh`) |
| hyprlock / hypridle | i3lock(-color) + xss-lock + `xset dpms` |
| wlogout | rofi power menu (`Powermenu.sh`) |
| grim / slurp | maim + xdotool + xclip |
| wl-copy / cliphist | xclip / clipmenu (CopyQ on Fedora) |
| hyprsunset | redshift (`Nightlight.sh`) |
| `[input]` block | `Input.sh` (setxkbmap / xset / xinput) |
| Special workspace | i3 scratchpad |
| Window groups | i3 tabbed / stacked containers |
| Quickshell / AGS overview | rofi window switcher (`SUPER+A`) |

## Keybinds (highlights)

| Keys | Action |
|---|---|
| `SUPER+Return` / `SUPER+D` / `SUPER+E` | terminal / launcher / file manager |
| `SUPER+Q` | close window |
| `SUPER+Arrows` · `SUPER+CTRL+Arrows` · `SUPER+SHIFT+Arrows` | focus · move · resize |
| `SUPER+1…0` · `SUPER+SHIFT+1…0` | workspace · move window to workspace |
| `SUPER+F` · `SUPER+SPACE` | fullscreen · floating |
| `SUPER+ALT+1/2/3` | split / stacking / tabbed layout |
| `SUPER+SHIFT+Return` · `SUPER+U` | drop-down terminal · scratchpad |
| `SUPER+W` · `CTRL+ALT+W` | pick wallpaper · random wallpaper |
| `SUPER+SHIFT+S` · `SUPER+Print` | screenshot (annotate) · screenshot |
| `SUPER+ALT+V` · `SUPER+ALT+E` · `SUPER+ALT+C` | clipboard · emoji · calculator |
| `CTRL+ALT+L` · `CTRL+ALT+P` | lock · power menu |
| `SUPER+SHIFT+E` | quick settings (edit configs, reload, restart) |

Everything else: `SUPER + H`. To add your own bind, edit `~/.config/i3/config` and put a `## description` line above it so it shows up in the cheat sheet.
Change your default terminal / file manager in `~/.config/i3/defaults.conf`.

## Not ported (Hyprland/Wayland-specific)

Animation menus and presets, the dwindle/master/scrolling layout switcher, rainbow borders, the Hyprview/Quickshell/AGS overviews,
the monitor-profile manager (use `arandr`, `SUPER+ALT+D`), Waybar style/layout menus, hyprlock themes, Hyprland portal scripts,
and the original distro installers (`copy.sh`, `Distro-Hyprland.sh`, dots-tui).

## Dependencies

`i3 (≥4.22) xorg polybar picom dunst rofi kitty feh maim xdotool xclip xss-lock i3lock imagemagick brightnessctl pamixer playerctl pavucontrol nm-applet redshift clipmenu|copyq numlockx xinput xrandr xprop xdpyinfo setxkbmap libnotify mpv qalc jq curl arandr thunar lxappearance fastfetch`
· optional: `pokemon-colorscripts`, `swappy`/`flameshot`, `i3lock-color`, `polkit-gnome`, *FantasqueSansM Nerd Font*.

## Credits & license

All configs, themes and most scripts originate from **[LinuxBeginnings/Hyprland-Dots](https://github.com/LinuxBeginnings/Hyprland-Dots)** (KooL Dots) — thank you to the original author and contributors.
This port is distributed under the same **GPL-3.0-or-later** license.
