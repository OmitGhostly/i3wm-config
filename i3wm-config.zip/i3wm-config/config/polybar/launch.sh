#!/usr/bin/env bash
# One polybar per monitor; tray on the primary monitor only.
pkill -x polybar 2>/dev/null
while pgrep -u "$UID" -x polybar >/dev/null; do sleep 0.2; done
primary=$(xrandr --query | awk '/ primary/{print $1; exit}')
for m in $(polybar --list-monitors | cut -d: -f1); do
  if [ "$m" = "$primary" ] || [ -z "$primary" ]; then tray=right; else tray=none; fi
  MONITOR=$m TRAY_POSITION=$tray polybar --reload main >/tmp/polybar-"$m".log 2>&1 &
  [ -z "$primary" ] && break
done
