#!/usr/bin/env bash
# Drop-down terminal via i3 scratchpad (window rule in the i3 config floats/sizes it).
if xdotool search --class kitty-dropterm >/dev/null 2>&1; then
  i3-msg '[class="kitty-dropterm"] scratchpad show' >/dev/null
else
  kitty --class kitty-dropterm &
fi
