#!/usr/bin/env bash
# Monochrome Pokemon fastfetch: random pokemon sprite + system info.
# Falls back to plain fastfetch when pokemon-colorscripts is missing.
cfg="${XDG_CONFIG_HOME:-$HOME/.config}/fastfetch/config-pokemon.jsonc"
command -v fastfetch >/dev/null || exit 0
if command -v pokemon-colorscripts >/dev/null; then
  pokemon-colorscripts --no-title -r 1>/tmp/.pokefetch.$$ 2>/dev/null
  fastfetch -c "$cfg" --logo-type file-raw --logo "/tmp/.pokefetch.$$" 2>/dev/null
  rm -f "/tmp/.pokefetch.$$"
else
  fastfetch -c "$cfg"
fi
