#!/usr/bin/env bash
source "${XDG_CONFIG_HOME:-$HOME/.config}/i3/defaults.conf" 2>/dev/null
term="${1:-${term:-kitty}}"
command -v "${term%% *}" >/dev/null || { notify-send -u critical "Terminal" "'$term' not found"; exit 1; }
exec $term
